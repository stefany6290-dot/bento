-- 執行於新的 Supabase 專案 SQL Editor。此檔不會匯入舊網站的真實訂單。
begin;
create table if not exists public.staff_users(user_id uuid primary key references auth.users(id));
create table if not exists public.shop_settings(id int primary key default 1 check(id=1), paused boolean not null default false, config jsonb not null default '{"capacity":15,"minutes":3,"soldOut":[],"lunchStart":"11:00","lunchEnd":"13:00","dinnerStart":"17:00","dinnerEnd":"19:00"}');
insert into public.shop_settings(id) values(1) on conflict do nothing;
create table if not exists public.menu_items(id int primary key, name text not null, price int not null, category text not null, ingredient text not null, description text not null);
create table if not exists public.shop_orders(seq bigint generated always as identity primary key,id uuid unique not null default gen_random_uuid(),day date not null,created timestamptz not null default now(),status text not null check(status in ('pending','preparing','ready','completed','cancelled')),paid int not null default 0 check(paid in(0,1)),source text not null check(source in('online','onsite')),pickup int not null,payload jsonb not null,unique(day,pickup));
create index if not exists shop_orders_day_idx on public.shop_orders(day);
alter table public.staff_users enable row level security;
alter table public.shop_settings enable row level security;
alter table public.menu_items enable row level security;
alter table public.shop_orders enable row level security;
revoke all on public.staff_users,public.shop_settings,public.menu_items,public.shop_orders from anon,authenticated;
create or replace function public.shop_api(b jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare
 cfg jsonb; paused boolean; staff boolean; act text:=coalesce(b->>'action','read');
 d date:=(now() at time zone 'Asia/Taipei')::date; tm time:=(now() at time zone 'Asia/Taipei')::time;
 ls time; le time; ds time; de time; peak boolean; cap int; duration int;
 slots jsonb:='[]'; t timestamptz; timeofday time; used int; remaining int; queue int;
 selected timestamptz; order_id uuid; old public.shop_orders%rowtype; m public.menu_items%rowtype;
 item jsonb; result_items jsonb:='[]'; chosen jsonb; n int; qty int; required_sides int; price int; total int:=0; portions int:=0; no_sides boolean; source text; phone text; pay int; next_status text; p jsonb; num int; data jsonb; reason text;
begin
 select exists(select 1 from public.staff_users where user_id=auth.uid()) into staff;
 -- Lock settings for write operations. This serializes capacity checks and daily pickup assignment.
 if act='read' then select s.config,s.paused into cfg,paused from public.shop_settings s where s.id=1;
 else select s.config,s.paused into cfg,paused from public.shop_settings s where s.id=1 for update; end if;
 cap:=(cfg->>'capacity')::int;duration:=(cfg->>'minutes')::int;
 ls:=(cfg->>'lunchStart')::time;le:=(cfg->>'lunchEnd')::time;ds:=(cfg->>'dinnerStart')::time;de:=(cfg->>'dinnerEnd')::time;
 peak:=(tm>=ls and tm<le) or (tm>=ds and tm<de);
 if act='read' then
  if not peak then slots:=slots||jsonb_build_array(jsonb_build_object('time','asap','remaining',null));end if;
  for n in 0..95 loop
   timeofday:=make_time(n/4,mod(n,4)*15,0);t:=(d+timeofday) at time zone 'Asia/Taipei';
   if t<=now() then continue;end if;
   remaining:=null;
   if (timeofday>=ls and timeofday<le) or (timeofday>=ds and timeofday<de) then
    select coalesce(sum((j->>'qty')::int),0) into used from public.shop_orders o cross join lateral jsonb_array_elements(o.payload->'items') j where o.day=d and o.status<>'cancelled' and o.source='online' and o.payload->>'slot'=to_char(t at time zone 'Asia/Taipei','YYYY-MM-DD"T"HH24:MI:SS')||'+08:00';
    remaining:=greatest(0,cap-used);
   end if;
   slots:=slots||jsonb_build_array(jsonb_build_object('time',to_char(t at time zone 'Asia/Taipei','YYYY-MM-DD"T"HH24:MI:SS')||'+08:00','remaining',remaining));
  end loop;
  select coalesce(sum((j->>'qty')::int),0) into queue from public.shop_orders o cross join lateral jsonb_array_elements(o.payload->'items') j where o.day=d and o.status in('pending','preparing') and (o.payload->>'slot' is null or (o.payload->>'slot')::timestamptz<=now());
  data:=jsonb_build_object('config',cfg,'paused',paused,'slots',slots,'wait',greatest(5,queue*duration));
  if nullif(b->>'track','') is not null then
   select (to_jsonb(o)-'payload')||(o.payload-'phone') into p from public.shop_orders o where o.id=(b->>'track')::uuid;
   return data||jsonb_build_object('order',p);
  elsif coalesce((b->>'staff')::boolean,false) then
   if not staff then raise exception '此帳號沒有店家管理權限';end if;
   select coalesce(jsonb_agg((to_jsonb(o)-'payload')||o.payload order by o.created),'[]') into p from public.shop_orders o;
   return data||jsonb_build_object('orders',p);
  end if;
  return data;
 elsif act='pause' then
  if not staff then raise exception '需要店家權限';end if;
  update public.shop_settings set paused=(b->>'value')::boolean where id=1;
 elsif act='service' then
  if not staff then raise exception '需要店家權限';end if;
  if not ((b->>'capacity')~'^[0-9]+$' and (b->>'minutes')~'^[0-9]+$') or (b->>'capacity')::int not between 1 and 100 or (b->>'minutes')::int not between 1 and 30 then raise exception '份數上限需 1–100，每份分鐘需 1–30';end if;
  if b->>'capacity' is null or b->>'minutes' is null then raise exception '缺少接單設定';end if;
  if not coalesce(((b->>'lunchStart')~'^([01][0-9]|2[0-3]):(00|15|30|45)$' and (b->>'lunchEnd')~'^([01][0-9]|2[0-3]):(00|15|30|45)$' and (b->>'dinnerStart')~'^([01][0-9]|2[0-3]):(00|15|30|45)$' and (b->>'dinnerEnd')~'^([01][0-9]|2[0-3]):(00|15|30|45)$'),false) then raise exception '尖峰時間請使用 15 分鐘間隔';end if;
  ls:=(b->>'lunchStart')::time;le:=(b->>'lunchEnd')::time;ds:=(b->>'dinnerStart')::time;de:=(b->>'dinnerEnd')::time;
  if not(ls<le and le<=ds and ds<de) then raise exception '時間需依序為午餐開始、結束、晚餐開始、結束';end if;
  if coalesce(jsonb_typeof(b->'soldOut'),'null')<>'array' then raise exception '售完設定錯誤';end if;
  update public.shop_settings set config=jsonb_build_object('capacity',(b->>'capacity')::int,'minutes',(b->>'minutes')::int,'soldOut',b->'soldOut','lunchStart',b->>'lunchStart','lunchEnd',b->>'lunchEnd','dinnerStart',b->>'dinnerStart','dinnerEnd',b->>'dinnerEnd') where id=1;
 elsif act='update' then
  if not staff then raise exception '需要店家權限';end if;
  select * into old from public.shop_orders where id=(b->>'id')::uuid for update;
  if not found then raise exception '找不到訂單';end if;
  next_status:=coalesce(b->>'status',old.status);pay:=case when coalesce((b->>'paid')::boolean,false) then 1 else old.paid end;
  if next_status<>old.status and not ((old.status='pending' and next_status in('preparing','cancelled')) or (old.status='preparing' and next_status in('ready','cancelled')) or (old.status='ready' and next_status in('completed','cancelled'))) then raise exception '訂單已更新，請重新整理';end if;
  if old.status in('completed','cancelled') then raise exception '已結束的訂單不可變更';end if;
  if next_status='completed' and pay=0 then raise exception '請先確認收款';end if;
  p:=old.payload;
  if next_status='cancelled' then
   if pay=1 then raise exception '已收款訂單暫不支援取消／退款';end if;
   reason:=trim(coalesce(b->>'reason',''));if length(reason)=0 then raise exception '請輸入取消原因';end if;
   p:=p||jsonb_build_object('cancelReason',left(reason,200));
  end if;
  update public.shop_orders set status=next_status,paid=pay,payload=p where id=old.id;
 elsif act='create' then
  source:=case when b->>'source'='onsite' then 'onsite' else 'online' end;
  if source='onsite' and not staff then raise exception '現場點餐需要店家權限';end if;
  order_id:=(b->>'requestId')::uuid;if order_id is null then raise exception '缺少送單識別碼';end if;
  if exists(select 1 from public.shop_orders where id=order_id) then return jsonb_build_object('id',order_id);end if;
  if source='online' and paused then raise exception '目前暫停線上接單';end if;
  phone:=regexp_replace(coalesce(b->>'phone',''),'[\s()-]','','g');
  if source='online' and phone!~'^0[0-9]{8,9}$' then raise exception '請輸入有效電話';end if;
  if coalesce(jsonb_typeof(b->'items'),'null')<>'array' or jsonb_array_length(b->'items') not between 1 and 20 then raise exception '請選擇 1–20 筆餐點';end if;
  for item in select value from jsonb_array_elements(b->'items') loop
   select * into m from public.menu_items where id=(item->>'id')::int;if not found then raise exception '餐點不存在';end if;
   if cfg->'soldOut' @> jsonb_build_array(m.id) then raise exception '% 今日售完',m.name;end if;
   if coalesce(item->>'qty','')!~'^[0-9]+$' then raise exception '數量錯誤';end if;
   qty:=(item->>'qty')::int;if qty not between 1 and 99 then raise exception '數量需 1–99';end if;
   no_sides:=coalesce((item->>'noSides')::boolean,false) and m.category='定食';
   chosen:=coalesce(item->'sides','[]');if jsonb_typeof(chosen)<>'array' then raise exception '配菜錯誤';end if;
   required_sides:=case when m.category='單點' or no_sides then 0 when m.id in(11,19) then 2 else 3 end;
   select count(distinct v) into n from jsonb_array_elements_text(chosen) v where v=any(array['高麗菜','花椰菜','炒豆芽','紅蘿蔔炒蛋','滷豆干','玉米']);
   if not no_sides and (n<>required_sides or jsonb_array_length(chosen)<>required_sides) then raise exception '請選擇正確配菜數量';end if;
   if no_sides then chosen:='[]';end if;
   price:=m.price-case when no_sides then 20 else 0 end;total:=total+price*qty;portions:=portions+qty;
   result_items:=result_items||jsonb_build_array(jsonb_build_object('id',m.id,'name',m.name,'price',price,'category',m.category,'ingredient',m.ingredient,'qty',qty,'sides',chosen,'noSides',no_sides));
  end loop;
  if portions>99 then raise exception '單筆最多 99 份';end if;
  selected:=null;
  if source='online' then
   if b->>'slot'='asap' then
    if peak then raise exception '現在是尖峰時段，請選擇預約時間';end if;
   else
    selected:=(b->>'slot')::timestamptz;
    if selected is null or selected<=now() or (selected at time zone 'Asia/Taipei')::date<>d or extract(minute from selected)::int%15<>0 or extract(second from selected)<>0 then raise exception '請選有效的今日預約時段';end if;
    timeofday:=(selected at time zone 'Asia/Taipei')::time;
    if (timeofday>=ls and timeofday<le) or (timeofday>=ds and timeofday<de) then
     select coalesce(sum((j->>'qty')::int),0) into used from public.shop_orders o cross join lateral jsonb_array_elements(o.payload->'items') j where o.day=d and o.status<>'cancelled' and o.source='online' and (o.payload->>'slot')::timestamptz=selected;
     if used+portions>cap then raise exception '此尖峰時段名額不足，請選其他時間';end if;
    end if;
   end if;
  end if;
  select coalesce(max(pickup),0)+1 into num from public.shop_orders where day=d;
  p:=jsonb_build_object('items',result_items,'total',total,'phone',left(phone,20),'note',left(coalesce(b->>'note',''),300),'slot',case when selected is null then null else to_char(selected at time zone 'Asia/Taipei','YYYY-MM-DD"T"HH24:MI:SS')||'+08:00' end);
  insert into public.shop_orders(id,day,status,paid,source,pickup,payload) values(order_id,d,case when source='online' then 'pending' else 'preparing' end,case when source='onsite' then 1 else 0 end,source,num,p);
  return jsonb_build_object('id',order_id);
 else raise exception '無效操作';end if;
 return jsonb_build_object('ok',true);
end;$$;
revoke all on function public.shop_api(jsonb) from public;
grant execute on function public.shop_api(jsonb) to anon,authenticated;
-- menu seed appended below

insert into public.menu_items(id,name,price,category,ingredient,description) values
(0,'燒肉丼',90,'丼飯','豬肉','經典炙燒，鹹甜剛剛好'),
(1,'唐揚雞丼',90,'丼飯','雞肉','酥脆多汁，每一口都滿足'),
(2,'日式炸豬排丼',90,'丼飯','豬肉','金黃厚切，日式好滋味'),
(3,'黃金雞排丼',90,'丼飯','雞肉','外酥內嫩的人氣選擇'),
(4,'脆雞丼',90,'丼飯','雞肉','香酥雞肉搭配熱騰騰米飯'),
(5,'親子丼',90,'丼飯','雞肉','滑嫩蛋香，溫柔的家常味'),
(6,'蒲燒鯛魚丼',90,'丼飯','魚肉','蒲燒醬香與細緻魚肉'),
(7,'日式照燒里肌肉排丼',90,'丼飯','豬肉','濃郁照燒，越吃越喜歡'),
(8,'日式炸豬排定食',85,'定食','豬肉','主餐與三樣配菜'),
(9,'唐揚雞定食',85,'定食','雞肉','主餐與三樣配菜'),
(10,'蒲燒鯛魚定食',85,'定食','魚肉','主餐與三樣配菜'),
(11,'紅燒牛腩飯',100,'定食','牛肉','附兩樣配菜'),
(12,'燉雞定食',85,'定食','雞肉','慢燉入味'),
(13,'脆雞定食',85,'定食','雞肉','金黃酥脆'),
(14,'黃金雞排定食',85,'定食','雞肉','主餐與三樣配菜'),
(15,'梅花肉片定食',85,'定食','豬肉','鮮嫩梅花肉'),
(16,'燒肉定食',85,'定食','豬肉','經典醬燒'),
(17,'日式照燒里肌肉排定食',90,'定食','豬肉','日式照燒'),
(18,'菜飯',55,'定食','蔬菜','三樣時蔬'),
(19,'黑胡椒牛柳飯',100,'定食','牛肉','附兩樣配菜'),
(20,'燒肉咖哩',95,'咖哩','豬肉','溫潤咖哩，配三樣時蔬'),
(21,'唐揚雞咖哩',95,'咖哩','雞肉','溫潤咖哩，配三樣時蔬'),
(22,'日式炸豬排咖哩',95,'咖哩','豬肉','溫潤咖哩，配三樣時蔬'),
(23,'嫩雞咖哩',95,'咖哩','雞肉','溫潤咖哩，配三樣時蔬'),
(24,'脆雞咖哩',95,'咖哩','雞肉','溫潤咖哩，配三樣時蔬'),
(25,'黃金雞排咖哩',95,'咖哩','雞肉','溫潤咖哩，配三樣時蔬'),
(26,'蒲燒鯛魚咖哩',95,'咖哩','魚肉','溫潤咖哩，配三樣時蔬'),
(27,'梅花肉片咖哩',95,'咖哩','豬肉','溫潤咖哩，配三樣時蔬'),
(28,'日式照燒里肌肉排咖哩',95,'咖哩','豬肉','溫潤咖哩，配三樣時蔬'),
(29,'原味咖哩',65,'咖哩','蔬菜','濃郁日式咖哩'),
(30,'唐揚雞',40,'單點','雞肉','加一份喜歡的主餐'),
(31,'燉雞',40,'單點','雞肉','加一份喜歡的主餐'),
(32,'黃金雞排',40,'單點','雞肉','加一份喜歡的主餐'),
(33,'蒲燒鯛魚',40,'單點','魚肉','加一份喜歡的主餐'),
(34,'梅花肉片',40,'單點','豬肉','加一份喜歡的主餐'),
(35,'燒肉',40,'單點','豬肉','加一份喜歡的主餐'),
(36,'日式炸豬排',40,'單點','豬肉','加一份喜歡的主餐'),
(37,'脆雞',45,'單點','雞肉','酥脆加點'),
(38,'日式照燒里肌肉排',45,'單點','豬肉','照燒加點'),
(39,'貢丸蛋花湯',30,'單點','湯品','暖心熱湯'),
(40,'荷包蛋／滑蛋',15,'單點','蛋','加點蛋香'),
(41,'配菜（每樣）',10,'單點','蔬菜','今日時蔬')
on conflict(id) do update set name=excluded.name,price=excluded.price,category=excluded.category,ingredient=excluded.ingredient,description=excluded.description;
commit;
