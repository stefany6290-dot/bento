# 丼物園專案規則

請用繁體中文說明修改與測試結果。
前端只使用原生 HTML、CSS、JavaScript。不要加入 React、TypeScript、Vite 或 npm 建置。
顧客入口 index.html，商家入口 pos.html，維持兩邊獨立。不要在顧客導覽加入店家入口。
兩邊共用 Supabase PostgreSQL 的 shop_api SQL 函式。不要把資料庫驗證改成只由前端檢查。
config.js 只能放公開 URL 與 anon/publishable key，不可放秘密金鑰、密碼、service_role。
保留莫蘭迪奶油白、深綠、橘色、玻璃質感與粉圓字體。不要加入餐點照片。
保留一般時段立即／預約下單，午晚尖峰每15分鐘控量，取消釋出名額，今日清單與歷史分析。
改動前先讀 README.md。針對任務做必要修改，描述檢查結果，無法完成的雲端驗收必須標明。
